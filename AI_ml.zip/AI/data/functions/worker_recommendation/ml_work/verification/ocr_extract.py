
from pathlib import Path

import pytesseract
from PIL import Image


def extract_text_from_image(image_path):
    """
    Extract text from a certificate image using OCR.

    Parameters
    ----------
    image_path : str or Path
        Path to the certificate image.

    Returns
    -------
    str
        Extracted OCR text.
    """

    image_path = Path(image_path)

    if not image_path.exists():
        raise FileNotFoundError(
            f"Certificate image not found: {image_path}"
        )

    image = Image.open(image_path)

    text = pytesseract.image_to_string(image)

    return text.strip()
