def compute_trust_score(
    reliability_score,
    completion_rate,
    rating,
    cancellation_rate
):
    """
    Calculate a worker trust score between 0 and 1.

    Weights:
        Reliability      = 40%
        Completion rate  = 30%
        Rating           = 20%
        Low cancellation = 10%
    """

    reliability_score = max(
        0.0, min(float(reliability_score), 1.0)
    )

    completion_rate = max(
        0.0, min(float(completion_rate), 1.0)
    )

    rating_score = max(
        0.0, min(float(rating) / 5.0, 1.0)
    )

    cancellation_score = max(
        0.0, min(1.0 - float(cancellation_rate), 1.0)
    )

    trust_score = (
        0.40 * reliability_score
        + 0.30 * completion_rate
        + 0.20 * rating_score
        + 0.10 * cancellation_score
    )

    return round(trust_score, 4)
