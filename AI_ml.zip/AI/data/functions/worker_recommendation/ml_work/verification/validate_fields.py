import pandas as pd

import re


def extract_fields(ocr_text):
    """
    Extract important certificate fields from OCR text.
    """

    fields = {
        "worker_name": None,
        "certificate": None,
        "skill": None,
        "certificate_id": None,
        "issue_date": None
    }

    patterns = {
        "worker_name": r"Worker Name:\s*(.+)",
        "certificate": r"Certificate:\s*(.+)",
        "skill": r"Skill:\s*(.+)",
        "certificate_id": r"Certificate ID:\s*(.+)",
        "issue_date": r"Issue Date:\s*(\d{4}-\d{2}-\d{2})"
    }

    for field, pattern in patterns.items():
        match = re.search(pattern, ocr_text, re.IGNORECASE)

        if match:
            fields[field] = match.group(1).strip()

    return fields


def validate_fields(fields):
    """
    Validate that all required certificate fields are present.
    """

    required_fields = [
        "worker_name",
        "certificate",
        "skill",
        "certificate_id",
        "issue_date"
    ]

    missing_fields = [
        field
        for field in required_fields
        if not fields.get(field)
    ]

    return {
        "valid": len(missing_fields) == 0,
        "missing_fields": missing_fields
    }


def validate_certification(
    certificate,
    required_certification
):
    """
    Check whether the certificate matches
    the required worker certification.

    If no certification is required, validation passes.
    """

    if pd.isna(required_certification) or not str(
        required_certification
    ).strip():
        return True

    if not certificate:
        return False

    return (
        str(certificate).strip().lower()
        == str(required_certification).strip().lower()
    )


def validate_worker_certificate(
    certificate_worker_name,
    worker_name,
    certificate,
    worker_certification,
    required_certification
):
    """
    Validate that a certificate belongs to the specified worker
    and that the worker's certification matches the service requirement.
    """

    # Check certificate owner
    if not certificate_worker_name or not worker_name:
        return False

    owner_match = (
        str(certificate_worker_name).strip().lower()
        == str(worker_name).strip().lower()
    )

    if not owner_match:
        return False

    # Check service certification requirement
    certification_valid = validate_certification(
        certificate,
        required_certification
    )

    if not certification_valid:
        return False

    # Check worker's stored certification
    if required_certification is not None:
        if pd.notna(required_certification):
            if not worker_certification:
                return False

            if (
                str(worker_certification).strip().lower()
                != str(required_certification).strip().lower()
            ):
                return False

    return True


def verify_certificate(
    image_path,
    worker,
    required_certification
):
    """
    Complete certificate verification pipeline.

    Steps:
    1. Extract text using OCR.
    2. Extract certificate fields.
    3. Validate required fields.
    4. Validate certificate ownership.
    5. Validate required certification.
    """

    from ocr_extract import extract_text_from_image

    # Step 1: OCR
    ocr_text = extract_text_from_image(image_path)

    # Step 2: Extract fields
    fields = extract_fields(ocr_text)

    # Step 3: Validate required fields
    field_validation = validate_fields(fields)

    if not field_validation["valid"]:
        return {
            "verified": False,
            "reason": "Missing required certificate fields",
            "missing_fields": field_validation["missing_fields"],
            "fields": fields
        }

    # Step 4 + 5: Validate worker and certification
    worker_validation = validate_worker_certificate(
        certificate_worker_name=fields["worker_name"],
        worker_name=worker["worker_name"],
        certificate=fields["certificate"],
        worker_certification=worker["certification"],
        required_certification=required_certification
    )

    if not worker_validation:
        return {
            "verified": False,
            "reason": "Worker ownership or certification validation failed",
            "fields": fields
        }

    return {
        "verified": True,
        "reason": "Certificate verified successfully",
        "fields": fields
    }
