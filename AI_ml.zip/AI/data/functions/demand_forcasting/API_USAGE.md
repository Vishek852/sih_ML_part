
# Demand Forecasting API

## Overview

This API provides demand forecasting using an XGBoost Poisson regression model.

The API is built with FastAPI.

## Start the API

From the `src` directory:

    python -m uvicorn app:app --host 127.0.0.1 --port 8000

API URL:

    http://127.0.0.1:8000

Interactive documentation:

    http://127.0.0.1:8000/docs

## Endpoints

### 1. Health Check

    GET /

Response:

    {
        "message": "Demand Forecasting API is running",
        "status": "healthy"
    }

### 2. Available Services

    GET /services

Returns the 11 supported service categories.

### 3. Available Areas

    GET /areas

Returns the 10 supported areas.

### 4. Single-Day Prediction

    POST /predict

Request:

    {
        "date": "2026-08-27",
        "service_category": "Appliance",
        "area": "Central"
    }

Response:

    {
        "date": "2026-08-27",
        "service_category": "Appliance",
        "area": "Central",
        "predicted_demand": 1.2173100709915161,
        "rounded_demand": 1
    }

### 5. Multi-Day Forecast

    POST /forecast

Request:

    {
        "start_date": "2026-08-27",
        "end_date": "2026-09-10",
        "service_category": "Appliance",
        "area": "Central"
    }

The endpoint returns one prediction for every day in the requested range.

## Error Handling

Unknown service:
HTTP 400

Unknown area:
HTTP 400

Missing required field:
HTTP 422

## Model Information

Model:
XGBoost

Objective:
count:poisson

Parameters:

    n_estimators = 800
    learning_rate = 0.03
    max_depth = 5
    min_child_weight = 3
    subsample = 0.8
    colsample_bytree = 0.8

## Test Performance

MAE:
0.7192

RMSE:
0.8733

R2:
0.0567

Within ±1 booking:
79.91%

## Model Files

    models/
    ├── demand_xgboost_poisson.json
    ├── demand_encoder.pkl
    └── model_summary.json

Historical data:

    data/processed/historical_demand.csv

## Python Example

    import requests

    response = requests.post(
        "http://127.0.0.1:8000/predict",
        json={
            "date": "2026-08-27",
            "service_category": "Appliance",
            "area": "Central"
        }
    )

    print(response.json())

## Architecture

    Client
      |
      | HTTP / JSON
      v
    FastAPI
      |
      v
    app.py
      |
      v
    predict.py
      |
      +--> XGBoost Poisson Model
      |
      +--> OneHotEncoder
      |
      +--> Historical Demand
      |
      v
    Demand Forecast
