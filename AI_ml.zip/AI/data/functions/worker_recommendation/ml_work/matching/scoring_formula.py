
from config_weights import (
    W1_SKILL,
    W2_DISTANCE,
    W3_QUALITY,
    W4_RELIABILITY
)


def calculate_matching_score(
    skill_score,
    distance_score,
    quality_score,
    reliability_score
):
    """
    Calculate the weighted worker matching score.

    All input scores should be normalized between 0 and 1.
    """

    score = (
        W1_SKILL * skill_score
        + W2_DISTANCE * distance_score
        + W3_QUALITY * quality_score
        + W4_RELIABILITY * reliability_score
    )

    return round(score, 4)


def apply_urgency_override(
    score,
    urgency,
    reliability_score
):
    """
    Apply an additional rule for urgent jobs.

    For urgent jobs, highly reliable workers receive
    a priority boost.

    Returns:
        float: final score
    """

    if urgency == "urgent" and reliability_score >= 0.90:
        score = score + 0.10

    return round(min(score, 1.0), 4)
