HTTPException
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from predict import (
    forecast_demand,
    recursive_forecast,
    load_historical_demand,
    get_valid_services,
    get_valid_areas
)


# -----------------------------
# Load historical data
# -----------------------------

historical_data = load_historical_demand()


# -----------------------------
# FastAPI application
# -----------------------------

app = FastAPI(
    title="Demand Forecasting API",
    description="AI-powered demand forecasting using XGBoost Poisson.",
    version="1.0.0"
)


# -----------------------------
# Request models
# -----------------------------

class ForecastRequest(BaseModel):

    date: str = Field(
        ...,
        description="Forecast date in YYYY-MM-DD format"
    )

    service_category: str = Field(
        ...,
        description="Service category"
    )

    area: str = Field(
        ...,
        description="Service area"
    )


class RecursiveForecastRequest(BaseModel):

    start_date: str = Field(
        ...,
        description="Forecast start date in YYYY-MM-DD format"
    )

    end_date: str = Field(
        ...,
        description="Forecast end date in YYYY-MM-DD format"
    )

    service_category: str = Field(
        ...,
        description="Service category"
    )

    area: str = Field(
        ...,
        description="Service area"
    )


# -----------------------------
# Health check
# -----------------------------

@app.get("/")
def root():

    return {
        "message": "Demand Forecasting API is running",
        "status": "healthy"
    }


# -----------------------------
# Available services
# -----------------------------

@app.get("/services")
def services():

    return {
        "services": get_valid_services(
            historical_data
        )
    }


# -----------------------------
# Available areas
# -----------------------------

@app.get("/areas")
def areas():

    return {
        "areas": get_valid_areas(
            historical_data
        )
    }


# -----------------------------
# Single-day forecast
# -----------------------------

@app.post("/predict")
def predict(request: ForecastRequest):

    try:

        result = forecast_demand(
            date=request.date,
            service_category=request.service_category,
            area=request.area,
            historical_data=historical_data
        )

        return result

    except ValueError as e:

        raise HTTPException(
            status_code=400,
            detail=str(e)
        )

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# -----------------------------
# Multi-day forecast
# -----------------------------

@app.post("/forecast")
def forecast(request: RecursiveForecastRequest):

    try:

        result = recursive_forecast(
            start_date=request.start_date,
            end_date=request.end_date,
            service_category=request.service_category,
            area=request.area,
            historical_data=historical_data
        )

        return {
            "forecast": result.to_dict(
                orient="records"
            )
        }

    except ValueError as e:

        raise HTTPException(
            status_code=400,
            detail=str(e)
        )

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )
