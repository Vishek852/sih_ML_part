
# AI Demand Forecasting

An AI-based demand forecasting system that predicts future service demand using an XGBoost Poisson regression model.

## Objective

The system predicts the expected number of service bookings for a given:

- Date
- Service category
- Area

The model is designed for count-based demand forecasting.

## Model

Algorithm:

XGBoost Regressor

Objective:

count:poisson

Hyperparameters:

- n_estimators: 800
- learning_rate: 0.03
- max_depth: 5
- min_child_weight: 3
- subsample: 0.8
- colsample_bytree: 0.8

## Features

Calendar features:

- day_of_week
- day_of_month
- month
- week_of_year
- is_weekend

Historical demand features:

- lag_1
- lag_7
- lag_14
- lag_28
- rolling_mean_7
- rolling_mean_14
- rolling_mean_28

Categorical features:

- service_category
- area

Categorical variables are transformed using OneHotEncoder.

## Dataset

Historical demand dataset:

- 23,100 rows
- 11 service categories
- 10 areas
- 210 observations per service-area combination
- Date range: 2026-01-29 to 2026-08-26

## Model Performance

Final test performance:

MAE: 0.7192

RMSE: 0.8733

R2: 0.0567

Within ±1 booking: 79.91%

## Saved Model Artifacts

The trained model and preprocessing objects are stored in:

    models/
    ├── demand_xgboost_poisson.json
    ├── demand_encoder.pkl
    └── model_summary.json

## Prediction Pipeline

    Input
      |
      v
    Date + Service + Area
      |
      v
    Feature Generation
      |
      v
    OneHotEncoder
      |
      v
    XGBoost Poisson Model
      |
      v
    Expected Demand
      |
      v
    Rounded Demand

## Recursive Forecasting

The system supports multi-day recursive forecasting.

For future dates where actual demand is unavailable, the previous predicted demand is added to the forecasting history and used to generate subsequent lag and rolling features.

## API

The project provides a FastAPI service.

Start the API:

    cd src
    python -m uvicorn app:app --host 127.0.0.1 --port 8000

API documentation:

    http://127.0.0.1:8000/docs

## Endpoints

### Health Check

    GET /

### Available Services

    GET /services

### Available Areas

    GET /areas

### Single-Day Prediction

    POST /predict

Example request:

    {
        "date": "2026-08-27",
        "service_category": "Appliance",
        "area": "Central"
    }

Example result:

    {
        "date": "2026-08-27",
        "service_category": "Appliance",
        "area": "Central",
        "predicted_demand": 1.2173100709915161,
        "rounded_demand": 1
    }

### Multi-Day Forecast

    POST /forecast

Example request:

    {
        "start_date": "2026-08-27",
        "end_date": "2026-09-10",
        "service_category": "Appliance",
        "area": "Central"
    }

## Validation

The API validates:

- Unknown service categories
- Unknown areas
- Missing required fields
- Invalid forecasting date ranges
- Insufficient historical data

HTTP responses:

- 200: Successful request
- 400: Invalid forecasting input
- 422: Request validation error
- 500: Internal server error

## Project Structure

    demand_forcasting/
    |
    ├── data/
    |   ├── raw/
    |   └── processed/
    |
    ├── models/
    |   ├── demand_xgboost_poisson.json
    |   ├── demand_encoder.pkl
    |   └── model_summary.json
    |
    ├── notebooks/
    |   └── 01_eda.ipynb
    |
    ├── src/
    |   ├── predict.py
    |   ├── app.py
    |   └── test_api.py
    |
    ├── API_USAGE.md
    ├── README.md
    └── requirements.txt

## Testing

Automated API tests are available in:

    src/test_api.py

The test suite verifies:

- API health
- Available services
- Available areas
- Single-day prediction
- Recursive forecasting

## Dependencies

Install dependencies with:

    pip install -r requirements.txt

Main technologies:

- Python
- Pandas
- NumPy
- Scikit-learn
- XGBoost
- Joblib
- FastAPI
- Uvicorn
