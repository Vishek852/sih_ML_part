
import pandas as pd

from haversine import haversine_distance_km
from scoring_formula import (
    calculate_matching_score,
    apply_urgency_override
)

from compute_trust_score import compute_trust_score


def normalize_rating(rating):
    """Convert 1-5 rating to 0-1."""
    return max(0.0, min(float(rating) / 5.0, 1.0))


def calculate_distance_score(distance_km):
    """Convert distance into a 0-1 score."""
    return 1.0 / (1.0 + distance_km)


def calculate_quality_score(worker):
    """
    Calculate worker quality from rating,
    completion rate and experience.
    """

    rating_score = normalize_rating(worker["rating"])

    completion_score = float(worker["completion_rate"])

    experience_score = min(
        float(worker["experience_years"]) / 10.0,
        1.0
    )

    quality_score = (
        0.40 * rating_score
        + 0.40 * completion_score
        + 0.20 * experience_score
    )

    return min(quality_score, 1.0)


def calculate_reliability_score(worker):
    """Calculate reliability using reliability and cancellation rate."""

    reliability = float(worker["reliability_score"])

    cancellation_score = 1.0 - float(worker["cancellation_rate"])

    score = (
        0.70 * reliability
        + 0.30 * cancellation_score
    )

    return min(max(score, 0.0), 1.0)


def calculate_skill_score(worker, service_category=None, required_skills=None):
    """
    Calculate skill/service compatibility.

    Primary service match receives the main score.
    Required skills are checked against worker skills.
    """

    score = 0.0

    if service_category is not None:
        if (
            str(worker["primary_service"]).strip().lower()
            == str(service_category).strip().lower()
        ):
            score = 1.0

    if required_skills:
        worker_skills = str(worker["skills"]).lower()
        matched = 0

        for skill in required_skills:
            if str(skill).lower() in worker_skills:
                matched += 1

        if len(required_skills) > 0:
            skill_match = matched / len(required_skills)
            score = max(score, skill_match)

    return min(score, 1.0)


def rank_workers(
    job_lat,
    job_lon,
    service_id,
    requested_date,
    requested_hour,
    workers_df,
    availability_df,
    services_df,
    urgency="normal",
    top_n=5
):
    """
    Rank available workers for a job.

    Returns:
        pandas.DataFrame containing ranked workers.
    """

    # 1. Find workers available at requested date/hour
    available = availability_df[
        (availability_df["date"].astype(str) == str(requested_date))
        & (availability_df["hour"] == requested_hour)
        & (availability_df["available"] == True)
    ]

    # 2. Get worker IDs
    available_worker_ids = available["worker_id"].unique()

    candidates = workers_df[
        workers_df["worker_id"].isin(available_worker_ids)
    ].copy()

    if candidates.empty:
        return pd.DataFrame()

    # Get service information
    service_matches = services_df[
        services_df["service_id"].astype(str) == str(service_id)
    ]

    if service_matches.empty:
        raise ValueError(f"Unknown service_id: {service_id}")

    service_info = service_matches.iloc[0]

    service_category = str(service_info["service_category"]).strip()
    required_skills = str(service_info["skills"]).split("|")

    # Keep only workers whose primary service matches the requested service
    candidates = candidates[
        candidates["primary_service"]
        .astype(str)
        .str.strip()
        .str.lower()
        == service_category.lower()
    ].copy()

    if candidates.empty:
        return pd.DataFrame()

    results = []

    # 3. Calculate scores for every candidate
    for _, worker in candidates.iterrows():

        distance_km = haversine_distance_km(
            job_lat,
            job_lon,
            worker["latitude"],
            worker["longitude"]
        )

        distance_score = calculate_distance_score(distance_km)

        skill_score = calculate_skill_score(
            worker,
            service_category=service_category,
            required_skills=required_skills
        )

        quality_score = calculate_quality_score(worker)

        reliability_score = calculate_reliability_score(worker)

        trust_score = compute_trust_score(
            reliability_score=worker["reliability_score"],
            completion_rate=worker["completion_rate"],
            rating=worker["rating"],
            cancellation_rate=worker["cancellation_rate"]
        )

        base_score = calculate_matching_score(
            skill_score,
            distance_score,
            quality_score,
            reliability_score
        )

        final_score = apply_urgency_override(
            base_score,
            urgency,
            reliability_score
        )

        results.append({
            "worker_id": worker["worker_id"],
            "worker_name": worker["worker_name"],
            "service": worker["primary_service"],
            "distance_km": round(distance_km, 2),
            "skill_score": round(skill_score, 4),
            "distance_score": round(distance_score, 4),
            "quality_score": round(quality_score, 4),
            "reliability_score": round(reliability_score, 4),
            "trust_score": trust_score,
            "matching_score": final_score
        })

    # 4. Convert to DataFrame
    ranked = pd.DataFrame(results)

    # 5. Highest score first
    ranked = ranked.sort_values(
        by="matching_score",
        ascending=False
    )

    # 6. Return top N workers
    return ranked.head(top_n).reset_index(drop=True)
