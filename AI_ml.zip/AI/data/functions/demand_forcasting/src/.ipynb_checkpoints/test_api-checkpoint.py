
import requests


BASE_URL = "http://127.0.0.1:8000"


def test_health():

    response = requests.get(
        f"{BASE_URL}/"
    )

    assert response.status_code == 200

    data = response.json()

    assert data["status"] == "healthy"

    print("Health check: PASSED")


def test_services():

    response = requests.get(
        f"{BASE_URL}/services"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data["services"]) == 11

    print("Services endpoint: PASSED")


def test_areas():

    response = requests.get(
        f"{BASE_URL}/areas"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data["areas"]) == 10

    print("Areas endpoint: PASSED")


def test_prediction():

    payload = {
        "date": "2026-08-27",
        "service_category": "Appliance",
        "area": "Central"
    }

    response = requests.post(
        f"{BASE_URL}/predict",
        json=payload
    )

    assert response.status_code == 200

    data = response.json()

    assert data["service_category"] == "Appliance"
    assert data["area"] == "Central"
    assert "predicted_demand" in data
    assert "rounded_demand" in data

    print("Prediction endpoint: PASSED")


def test_recursive_forecast():

    payload = {
        "start_date": "2026-08-27",
        "end_date": "2026-09-10",
        "service_category": "Appliance",
        "area": "Central"
    }

    response = requests.post(
        f"{BASE_URL}/forecast",
        json=payload
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data["forecast"]) == 15

    print("Recursive forecast endpoint: PASSED")


if __name__ == "__main__":

    print("API TESTS")
    print("=" * 40)

    test_health()
    test_services()
    test_areas()
    test_prediction()
    test_recursive_forecast()

    print("\nAll API tests PASSED.")
