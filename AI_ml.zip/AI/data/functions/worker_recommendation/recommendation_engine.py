
import math
import pickle
import pandas as pd


# ============================================================
# PATHS
# ============================================================

MODEL_PATH = "/home/vishek/AI/data/processed/issue_classifier_char.pkl"

VECTORIZER_PATH = (
    "/home/vishek/AI/data/processed/tfidf_char_vectorizer.pkl"
)

WORKERS_PATH = (
    "/home/vishek/AI/data/functions/worker_recommendation/"
    "workers.csv"
)

AVAILABILITY_PATH = (
    "/home/vishek/AI/data/functions/worker_recommendation/"
    "availability.csv"
)

SERVICES_PATH = (
    "/home/vishek/AI/data/functions/worker_recommendation/"
    "services.csv"
)


# ============================================================
# LOAD MODEL AND DATA
# ============================================================

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

with open(VECTORIZER_PATH, "rb") as f:
    vectorizer = pickle.load(f)

workers = pd.read_csv(WORKERS_PATH)

availability = pd.read_csv(
    AVAILABILITY_PATH,
    dtype={
        "worker_id": str,
        "date": str,
        "hour": int,
        "available": int,
        "current_jobs": int
    }
)

services = pd.read_csv(SERVICES_PATH)


# ============================================================
# SERVICE MAPPING
# ============================================================

ISSUE_TO_SERVICE = {
    "pipe_leak": "S001",
    "drain_blockage": "S002",
    "wiring_problem": "S003",
    "fan_installation": "S004",
    "furniture_repair": "S005",
    "wall_painting": "S006",
    "home_cleaning": "S007",
    "garden_maintenance": "S008",
    "elder_care": "S009",
    "local_transport": "S010",
    "ac_repair": "S011",
    "refrigerator_repair": "S012",
    "wall_repair": "S013",
    "computer_repair": "S014"
}


# ============================================================
# CONFIDENCE THRESHOLDS
# ============================================================

CONFIDENCE_THRESHOLD = 0.40
MARGIN_THRESHOLD = 0.15


# ============================================================
# NLP PREDICTION
# ============================================================

def predict_service(text):

    X = vectorizer.transform([text])

    probabilities = model.predict_proba(X)[0]

    classes = model.classes_

    ranked_indices = probabilities.argsort()[::-1]

    best_index = ranked_indices[0]

    second_index = ranked_indices[1]

    issue = classes[best_index]

    confidence = probabilities[best_index]

    second_confidence = probabilities[second_index]

    margin = confidence - second_confidence

    service_id = ISSUE_TO_SERVICE.get(issue)

    service_row = services[
        services["service_id"] == service_id
    ]

    if len(service_row) > 0:
        subservice = service_row.iloc[0]["subservice"]
    else:
        subservice = None

    if (
        confidence >= CONFIDENCE_THRESHOLD
        and margin >= MARGIN_THRESHOLD
    ):
        status = "accepted"
    else:
        status = "needs_clarification"

    return {
        "text": text,
        "issue": issue,
        "service_id": service_id,
        "subservice": subservice,
        "confidence": float(confidence),
        "confidence_percent": float(confidence * 100),
        "margin": float(margin),
        "margin_percent": float(margin * 100),
        "status": status
    }


# ============================================================
# DISTANCE
# ============================================================

def calculate_distance_km(
    lat1,
    lon1,
    lat2,
    lon2
):

    R = 6371.0

    lat1 = math.radians(lat1)
    lon1 = math.radians(lon1)

    lat2 = math.radians(lat2)
    lon2 = math.radians(lon2)

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1)
        * math.cos(lat2)
        * math.sin(dlon / 2) ** 2
    )

    c = 2 * math.atan2(
        math.sqrt(a),
        math.sqrt(1 - a)
    )

    return R * c


# ============================================================
# WORKER RANKING
# ============================================================

def rank_available_workers(
    service_id,
    customer_lat,
    customer_lon,
    requested_date,
    requested_hour,
    top_n=5
):

    service_row = services[
        services["service_id"] == service_id
    ]

    if service_row.empty:
        return pd.DataFrame()

    primary_service = service_row.iloc[0][
        "service_category"
    ]

    matched_workers = workers[
        workers["primary_service"] == primary_service
    ].copy()

    available_ids = availability[
        (availability["date"] == requested_date)
        & (availability["hour"] == requested_hour)
        & (availability["available"] == 1)
    ]["worker_id"]

    matched_workers = matched_workers[
        matched_workers["worker_id"].isin(available_ids)
    ].copy()

    if matched_workers.empty:
        return matched_workers

    # -----------------------------
    # Quality
    # -----------------------------

    matched_workers["rating_score"] = (
        matched_workers["rating"] / 5
    )

    max_experience = workers[
        "experience_years"
    ].max()

    matched_workers["experience_score"] = (
        matched_workers["experience_years"]
        / max_experience
    )

    matched_workers["cancellation_score"] = (
        1 - matched_workers["cancellation_rate"]
    )

    matched_workers["quality_score"] = (
        0.30 * matched_workers["rating_score"]
        + 0.30 * matched_workers["reliability_score"]
        + 0.20 * matched_workers["completion_rate"]
        + 0.10 * matched_workers["experience_score"]
        + 0.10 * matched_workers["cancellation_score"]
    )

    # -----------------------------
    # Distance
    # -----------------------------

    matched_workers["distance_km"] = matched_workers.apply(
        lambda row: calculate_distance_km(
            customer_lat,
            customer_lon,
            row["latitude"],
            row["longitude"]
        ),
        axis=1
    )

    matched_workers["distance_score"] = (
        1 / (1 + matched_workers["distance_km"])
    )

    # -----------------------------
    # Final score
    # -----------------------------

    matched_workers["worker_score"] = (
        0.80 * matched_workers["quality_score"]
        + 0.20 * matched_workers["distance_score"]
    )

    return matched_workers.sort_values(
        "worker_score",
        ascending=False
    ).head(top_n)


# ============================================================
# EXPLANATION
# ============================================================

def get_worker_explanation(worker):

    reasons = []

    if worker["rating"] >= 4.5:
        reasons.append("high rating")

    if worker["reliability_score"] >= 0.90:
        reasons.append("high reliability")

    if worker["completion_rate"] >= 0.90:
        reasons.append("high completion rate")

    if worker["cancellation_rate"] <= 0.05:
        reasons.append("low cancellation rate")

    if worker["distance_km"] <= 2:
        reasons.append("nearby")

    if worker["experience_years"] >= 10:
        reasons.append("experienced")

    if not reasons:
        reasons.append("good overall worker score")

    return ", ".join(reasons)


# ============================================================
# FINAL RECOMMENDATION
# ============================================================

def recommend(
    text,
    customer_lat,
    customer_lon,
    requested_date,
    requested_hour,
    top_n=5
):

    prediction = predict_service(text)

    response = {
        "request": text,
        "issue": prediction["issue"],
        "service_id": prediction["service_id"],
        "service": prediction["subservice"],
        "confidence": round(
            prediction["confidence_percent"],
            2
        ),
        "margin": round(
            prediction["margin_percent"],
            2
        ),
        "status": prediction["status"],
        "workers": []
    }

    # -----------------------------
    # Needs clarification
    # -----------------------------

    if prediction["status"] != "accepted":

        response["message"] = (
            "I couldn't determine which service you need. "
            "Please describe the problem in more detail, "
            "such as plumbing, electrical, cleaning, "
            "painting, repair, gardening, or caregiving."
        )

        return response

    # -----------------------------
    # Worker ranking
    # -----------------------------

    workers_df = rank_available_workers(
        service_id=prediction["service_id"],
        customer_lat=customer_lat,
        customer_lon=customer_lon,
        requested_date=requested_date,
        requested_hour=requested_hour,
        top_n=top_n
    )

    # -----------------------------
    # No workers
    # -----------------------------

    if workers_df.empty:

        response["status"] = "no_worker_available"

        response["message"] = (
            "No suitable worker is available for "
            "this service at the requested date and "
            "time. Please try another time."
        )

        return response

    # -----------------------------
    # Format workers
    # -----------------------------

    for _, worker in workers_df.iterrows():

        response["workers"].append({
            "worker_id": worker["worker_id"],
            "worker_name": worker["worker_name"],
            "worker_type": worker["worker_type"],
            "area": worker["area"],
            "distance_km": round(
                float(worker["distance_km"]),
                2
            ),
            "rating": float(worker["rating"]),
            "reliability": float(
                worker["reliability_score"]
            ),
            "completion_rate": float(
                worker["completion_rate"]
            ),
            "worker_score": round(
                float(worker["worker_score"]),
                4
            ),
            "reason": get_worker_explanation(worker)
        })

    response["message"] = (
        f"Found {len(response['workers'])} "
        "suitable workers."
    )

    return response
