numpy
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb


# -----------------------------
# Paths
# -----------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"
PROCESSED_DIR = BASE_DIR / "data" / "processed"


# -----------------------------
# Load saved model and encoder
# -----------------------------

model = xgb.XGBRegressor()

model.load_model(
    MODELS_DIR / "demand_xgboost_poisson.json"
)

encoder = joblib.load(
    MODELS_DIR / "demand_encoder.pkl"
)


# -----------------------------
# Feature definitions
# -----------------------------

categorical_features = [
    "service_category",
    "area"
]

numerical_features = [
    "day_of_week",
    "day_of_month",
    "month",
    "week_of_year",
    "is_weekend",
    "lag_1",
    "lag_7",
    "lag_14",
    "lag_28",
    "rolling_mean_7",
    "rolling_mean_14",
    "rolling_mean_28"
]


# -----------------------------
# Load historical demand
# -----------------------------

HISTORICAL_PATH = (
    PROCESSED_DIR / "historical_demand.csv"
)


# -----------------------------
# Basic prediction
# -----------------------------

def predict_demand(row):
    """
    Predict demand for one prepared row.
    """

    categorical_data = row[categorical_features]

    numerical_data = (
        row[numerical_features]
        .to_numpy()
        .reshape(1, -1)
    )

    encoded_data = encoder.transform(
        categorical_data
    )

    final_features = np.hstack([
        numerical_data,
        encoded_data
    ])

    prediction = model.predict(
        final_features
    )[0]

    return float(prediction)


# -----------------------------
# Load historical data
# -----------------------------

def load_historical_demand(
    historical_path=HISTORICAL_PATH
):
    """
    Load historical demand data used
    for lag and rolling features.
    """

    data = pd.read_csv(
        historical_path,
        parse_dates=["date"]
    )

    required_columns = [
        "date",
        "service_category",
        "area",
        "demand"
    ]

    missing_columns = [
        col for col in required_columns
        if col not in data.columns
    ]

    if missing_columns:
        raise ValueError(
            f"Missing columns: {missing_columns}"
        )

    return data.sort_values(
        ["service_category", "area", "date"]
    ).reset_index(drop=True)


# -----------------------------
# Valid inputs
# -----------------------------

def get_valid_services(
    historical_data
):
    return sorted(
        historical_data[
            "service_category"
        ].unique()
    )


def get_valid_areas(
    historical_data
):
    return sorted(
        historical_data[
            "area"
        ].unique()
    )


# -----------------------------
# Future feature generation
# -----------------------------

def create_future_features(
    service_category,
    area,
    future_date,
    historical_data
):
    """
    Create model features for a future date.
    """

    future_date = pd.Timestamp(
        future_date
    )

    history = historical_data[
        (historical_data["service_category"] == service_category) &
        (historical_data["area"] == area)
    ].copy()

    history = history.sort_values(
        "date"
    )

    demand_by_date = (
        history
        .set_index("date")["demand"]
        .sort_index()
    )

    # Calendar features
    day_of_week = future_date.dayofweek
    day_of_month = future_date.day
    month = future_date.month
    week_of_year = int(
        future_date.isocalendar().week
    )
    is_weekend = int(
        day_of_week >= 5
    )

    # Lag features
    lag_1 = demand_by_date.get(
        future_date - pd.Timedelta(days=1),
        np.nan
    )

    lag_7 = demand_by_date.get(
        future_date - pd.Timedelta(days=7),
        np.nan
    )

    lag_14 = demand_by_date.get(
        future_date - pd.Timedelta(days=14),
        np.nan
    )

    lag_28 = demand_by_date.get(
        future_date - pd.Timedelta(days=28),
        np.nan
    )

    # Rolling features
    previous_7_days = demand_by_date[
        (demand_by_date.index < future_date) &
        (demand_by_date.index >= future_date - pd.Timedelta(days=7))
    ]

    previous_14_days = demand_by_date[
        (demand_by_date.index < future_date) &
        (demand_by_date.index >= future_date - pd.Timedelta(days=14))
    ]

    previous_28_days = demand_by_date[
        (demand_by_date.index < future_date) &
        (demand_by_date.index >= future_date - pd.Timedelta(days=28))
    ]

    rolling_mean_7 = previous_7_days.mean()
    rolling_mean_14 = previous_14_days.mean()
    rolling_mean_28 = previous_28_days.mean()

    return pd.DataFrame({
        "service_category": [service_category],
        "area": [area],
        "day_of_week": [day_of_week],
        "day_of_month": [day_of_month],
        "month": [month],
        "week_of_year": [week_of_year],
        "is_weekend": [is_weekend],
        "lag_1": [lag_1],
        "lag_7": [lag_7],
        "lag_14": [lag_14],
        "lag_28": [lag_28],
        "rolling_mean_7": [rolling_mean_7],
        "rolling_mean_14": [rolling_mean_14],
        "rolling_mean_28": [rolling_mean_28]
    })


# -----------------------------
# Single future forecast
# -----------------------------

def forecast_demand(
    date,
    service_category,
    area,
    historical_data=None
):
    """
    Generate one future demand forecast.
    """

    if historical_data is None:
        historical_data = (
            load_historical_demand()
        )

    valid_services = get_valid_services(
        historical_data
    )

    valid_areas = get_valid_areas(
        historical_data
    )

    # Validate service
    if service_category not in valid_services:
        raise ValueError(
            f"Unknown service '{service_category}'. "
            f"Valid services: {valid_services}"
        )

    # Validate area
    if area not in valid_areas:
        raise ValueError(
            f"Unknown area '{area}'. "
            f"Valid areas: {valid_areas}"
        )

    features = create_future_features(
        service_category=service_category,
        area=area,
        future_date=date,
        historical_data=historical_data
    )

    if features[numerical_features].isna().any().any():
        raise ValueError(
            "Insufficient historical data to "
            "generate all required features."
        )

    prediction = predict_demand(
        features
    )

    return {
        "date": str(
            pd.Timestamp(date).date()
        ),
        "service_category": service_category,
        "area": area,
        "predicted_demand": float(
            prediction
        ),
        "rounded_demand": int(
            round(prediction)
        )
    }


# -----------------------------
# Recursive multi-day forecast
# -----------------------------

def recursive_forecast(
    start_date,
    end_date,
    service_category,
    area,
    historical_data=None
):
    """
    Forecast demand recursively across
    multiple future dates.
    """

    if historical_data is None:
        historical_data = (
            load_historical_demand()
        )

    start_date = pd.Timestamp(
        start_date
    )

    end_date = pd.Timestamp(
        end_date
    )

    last_historical_date = pd.Timestamp(
        historical_data["date"].max()
    )

    if start_date <= last_historical_date:
        raise ValueError(
            f"Start date must be after "
            f"{last_historical_date.date()}"
        )

    if end_date < start_date:
        raise ValueError(
            "End date must be greater than "
            "or equal to start date."
        )

    valid_services = get_valid_services(
        historical_data
    )

    valid_areas = get_valid_areas(
        historical_data
    )

    if service_category not in valid_services:
        raise ValueError(
            f"Unknown service '{service_category}'."
        )

    if area not in valid_areas:
        raise ValueError(
            f"Unknown area '{area}'."
        )

    history = historical_data[
        (historical_data["service_category"] == service_category) &
        (historical_data["area"] == area)
    ][
        ["date", "demand"]
    ].copy()

    history["date"] = pd.to_datetime(
        history["date"]
    )

    history = history.sort_values(
        "date"
    ).reset_index(drop=True)

    future_dates = pd.date_range(
        start=start_date,
        end=end_date,
        freq="D"
    )

    forecasts = []

    for future_date in future_dates:

        temp_history = history.copy()

        temp_history[
            "service_category"
        ] = service_category

        temp_history[
            "area"
        ] = area

        features = create_future_features(
            service_category=service_category,
            area=area,
            future_date=future_date,
            historical_data=temp_history
        )

        if features[numerical_features].isna().any().any():
            raise ValueError(
                f"Insufficient history for "
                f"{future_date.date()}."
            )

        prediction = predict_demand(
            features
        )

        prediction = float(
            prediction
        )

        forecasts.append({
            "date": future_date,
            "service_category": service_category,
            "area": area,
            "predicted_demand": prediction,
            "rounded_demand": int(
                round(prediction)
            )
        })

        history = pd.concat(
            [
                history,
                pd.DataFrame({
                    "date": [future_date],
                    "demand": [prediction]
                })
            ],
            ignore_index=True
        )

        history = history.sort_values(
            "date"
        ).reset_index(drop=True)

    return pd.DataFrame(
        forecasts
    )
