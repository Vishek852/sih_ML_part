
# Matching score weights
# These values can be tuned later based on evaluation results.

W1_SKILL = 0.40
W2_DISTANCE = 0.20
W3_QUALITY = 0.25
W4_RELIABILITY = 0.15


# Check that weights form a valid weighted score.
TOTAL_WEIGHT = (
    W1_SKILL
    + W2_DISTANCE
    + W3_QUALITY
    + W4_RELIABILITY
)

if TOTAL_WEIGHT != 1.0:
    raise ValueError(
        f"Matching weights must sum to 1.0, got {TOTAL_WEIGHT}"
    )
